# platform-notes.md — Expo / React Native fidelity

Read this **before** writing any UI. The prototype was authored in a browser on macOS; three
things do not carry over automatically, and they account for nearly all of the "it doesn't quite
look right" gap.

---

## 1. Font — the single biggest fidelity gap

`design.md` says "system sans". On iOS that resolves to SF Pro. **On Android it resolves to
Roboto**, whose numerals are wider, rounder and looser. A dashboard of prices set in Roboto reads
as a different product. This is not a framework problem — Flutter, native, and web all inherit it.
**Bundle one font and use it on both platforms.**

Use **Inter**. It is metrically close to SF, has true tabular numerals, and ships free.

```bash
npx expo install expo-font
npm i @expo-google-fonts/inter
```

```tsx
// app/_layout.tsx
import { useFonts, Inter_400Regular, Inter_500Medium,
         Inter_600SemiBold, Inter_700Bold } from '@expo-google-fonts/inter';
import * as SplashScreen from 'expo-splash-screen';

SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  const [ready] = useFonts({
    Inter_400Regular, Inter_500Medium, Inter_600SemiBold, Inter_700Bold,
  });
  useEffect(() => { if (ready) SplashScreen.hideAsync(); }, [ready]);
  if (!ready) return null;
  return <Stack screenOptions={{ headerShown: false }} />;
}
```

### Weight is a family, not a number
React Native's `fontWeight` is unreliable with custom fonts on Android — it will synthesise a fake
bold or ignore you. **Always select the weight by family name:**

```tsx
// ✅ right
{ fontFamily: 'Inter_700Bold' }
// ❌ wrong on Android
{ fontFamily: 'Inter', fontWeight: '700' }
```

### Tabular numerals — mandatory on every number
Without this, digits change width as values update and every price column shivers.

```tsx
<Text style={{ fontVariant: ['tabular-nums'] }}>$66,560</Text>
```

Put it in the `Value`/`Price` text primitives so it is impossible to forget.

---

## 2. Letter-spacing does not inherit

In CSS, `letter-spacing` cascades. In React Native it does **not** — it must sit on the `<Text>`
that renders the glyphs. Every large number in this design has negative tracking, and dropping it
is the second-largest source of the "off" feeling.

| Role | letterSpacing |
|---|---|
| Hero balance / P&L (46px) | `-1.4` |
| Keypad amount (52px) | `-2` |
| Price large (36–42px) | `-1.2` |
| Card / section numbers (30px) | `-1` |
| Eyebrow (10–11px, uppercase) | `+1.3` (≈ .12em) |
| Tag / badge (9.5–10px, uppercase) | `+0.9` (≈ .09em) |
| Tab label (9.5px) | `+0.3` |

RN takes **absolute points**, not em. Convert: `em × fontSize`.

---

## 3. Radial gradients need SVG

Agent orbs and asset marks are `radial-gradient(circle at 32% 26%, c1, c2 74%)`.
`expo-linear-gradient` cannot do radial — a linear fallback loses the specular highlight that
makes the orbs read as characters rather than colored circles. Use `react-native-svg`:

```bash
npx expo install react-native-svg
```

```tsx
<Svg width={size} height={size}>
  <Defs>
    <RadialGradient id="g" cx="32%" cy="26%" r="74%">
      <Stop offset="0" stopColor={c1} />
      <Stop offset="1" stopColor={c2} />
    </RadialGradient>
  </Defs>
  <Circle cx={size/2} cy={size/2} r={size/2} fill="url(#g)" />
</Svg>
```

**Size matters.** Orbs are 74px on the wallet home (inside a 106px card) and 84–104px on agent
detail. At 32px they read as emoji in a list. Keep them large — they are the product's identity.

---

## 4. Other RN gotchas in this design

| Browser behaviour | React Native |
|---|---|
| `gap` in flex | Supported in RN 0.71+. Use it; do not fall back to margins. |
| `box-shadow` | `shadowColor/Offset/Opacity/Radius` on iOS; `elevation` on Android. The candle bloom needs both, or use an SVG `<FeGaussianBlur>`/absolutely-positioned tinted layer. |
| `transition` | Not a thing. Use `react-native-reanimated` `withTiming(v, { duration })`. |
| `overflow-x: auto` | `<ScrollView horizontal showsHorizontalScrollIndicator={false}>`. |
| `:hover` | Does not exist on touch. Use `<Pressable>` `pressed` state → `opacity: .85`. |
| Percentage `top`/`height` in charts | Works, but only if the parent has a resolved height. Give chart containers an explicit height or `flex: 1` + `onLayout`. |
| `text-wrap: pretty` | No equivalent. Ignore. |
| Safe area | 54px top padding assumed a notch. Use `useSafeAreaInsets()` and add `insets.top + 10`. Bottom tab bar: `insets.bottom` instead of the hardcoded 22px. |
| Status bar | `<StatusBar style="light" />` globally — the app is always dark. |

---

## 5. Android-specific

- **Ripple.** Android's default touch ripple will fire on cards and rows and looks foreign here.
  Use `<Pressable android_ripple={null}>` and drive feedback with `opacity` so both platforms match.
- **Elevation adds a grey tint.** Android composites `elevation` with a light overlay that muddies
  `#0C0C0D` cards. Prefer the 1px `rgba(255,255,255,.06)` border (which the design already uses)
  and set `elevation: 0`.
- **Overscroll glow.** `overScrollMode="never"` on scroll views.
- **Font padding.** Android `<Text>` adds vertical padding that breaks tight numeric layouts. Set
  `includeFontPadding: false` in the base text style. **Do this globally — it fixes a lot of
  small vertical misalignment at once.**
- **Letter-spacing rounding.** Android rounds to whole pixels at small sizes; a 9.5px label with
  `+0.3` may look identical to `0`. Accept it.

---

## 6. Why not Flutter

The font mismatch is a platform default, not a framework limitation — Flutter's `ThemeData`
defaults to Roboto on Android too, and you would bundle Inter there exactly as above. Everything
else in this design (SVG charts, radial gradients, timed transitions, a 5-tab bottom navigator) is
well covered by the Expo stack. Switching frameworks does not close the gap; bundling the font,
setting `letterSpacing`, and sizing the orbs correctly does.
